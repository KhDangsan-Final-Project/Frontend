import React, { useState } from 'react';
import Sidebar from '../Menu/Sidebar';

export default function MainPage() {

    return (
        <>
        
        </>
    )
}