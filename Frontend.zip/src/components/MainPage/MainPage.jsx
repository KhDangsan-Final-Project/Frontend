import React from 'react';

export default function MainPage() {

    return (
        <>
        
        </>
    )
}