export default function MyPage() {
    
    return(
        <>
        <p>MyPage</p>
        </>
    )
}