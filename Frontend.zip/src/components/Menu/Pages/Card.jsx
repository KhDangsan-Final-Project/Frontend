export default function Card() {
    
    return(
        <>
        <p>Card</p>
        </>
    )
}